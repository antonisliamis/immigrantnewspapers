var mapLayer = L.tileLayer('https://api.mapbox.com/styles/v1/jenche/cjtgq262z04de1fn56eed4apn/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiamVuY2hlIiwiYSI6ImNqdjczdjJibDBjNGs0NG50ajZybWJiMzQifQ.KLfTJJ0-vPgLSh90Ks9T1w', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>, &copy; <a href="http://maps.nypl.org">Map Division</a>, NYPL, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a> | <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 16,
    minZoom: 14,
    accessToken: 'pk.eyJ1IjoiamVuY2hlIiwiYSI6ImNqdjczdjJibDBjNGs0NG50ajZybWJiMzQifQ.KLfTJJ0-vPgLSh90Ks9T1w'
});

// Establish map boundaries: https://stackoverflow.com/questions/22155017/can-i-prevent-panning-leaflet-map-out-of-the-worlds-edge
var southWest = L.latLng(40.691, -74.0239),
    northEast = L.latLng(40.914177, -73.862399);
var bounds = L.latLngBounds(southWest, northEast);

// https://asmaloney.com/2014/01/code/creating-an-interactive-map-with-leaflet-and-openstreetmap/
var myURL = jQuery('script[src$="map.js"]').attr('src').replace('map.js', '');

var czechIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/czech-marker.png',
    iconSize: [30, 45]
});

var frenchIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/french-marker.png',
    iconSize: [30, 45]
});

var germanIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/german-marker.png',
    iconSize: [30, 45]
});

var irishIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/irish-marker.png',
    iconSize: [30, 45]
});

var italianIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/italian-marker.png',
    iconSize: [30, 45]
});

var spanishIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/spanish-marker.png',
    iconSize: [30, 45]
});

var swedishIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/swedish-marker.png',
    iconSize: [30, 45]
});

var yiddishIcon = L.icon({
    iconUrl: myURL + 'http://immigrantnewspapers.org/wp-content/uploads/2019/04/yiddish-marker.png',
    iconSize: [30, 45]
});

var czech = L.layerGroup([]);
var english = L.layerGroup([]);
var french = L.layerGroup([]);
var german = L.layerGroup([]);
var italian = L.layerGroup([]);
var spanish = L.layerGroup([]);
var swedish = L.layerGroup([]);
var yiddish = L.layerGroup([]);
var allNewspapers = L.layerGroup([]);
var popupGrids = marker.features;

for (var i = 0; i < popupGrids.length; ++i) {
    var properties = popupGrids[i].properties;
    var srcCoordinates = popupGrids[i].geometry.coordinates;
    var coordinates = [srcCoordinates[1], srcCoordinates[0]];
    var newspaper = properties.newspaper;
    switch (properties.primaryLanguage) {
        case 'Czech':
            L.marker(coordinates, {
                    icon: czechIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(czech).addTo(allNewspapers);
            break;
        case 'English (Irish)':
            L.marker(coordinates, {
                    icon: irishIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(english).addTo(allNewspapers);
            break;
        case 'French':
            L.marker(coordinates, {
                    icon: frenchIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(french).addTo(allNewspapers);
            break;
        case 'German':
            L.marker(coordinates, {
                    icon: germanIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(german).addTo(allNewspapers);
            break;
        case 'Italian':
            L.marker(coordinates, {
                    icon: italianIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(italian).addTo(allNewspapers);
            break;
        case 'Spanish':
            L.marker(coordinates, {
                    icon: spanishIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(spanish).addTo(allNewspapers);
            break;
        case 'Swedish':
            L.marker(coordinates, {
                    icon: swedishIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(swedish).addTo(allNewspapers);
            break;
        case 'Yiddish':
            L.marker(coordinates, {
                    icon: yiddishIcon,
		    title: newspaper
                })
                .bindPopup(popupContent(properties))
                .addTo(yiddish).addTo(allNewspapers);
            break;
    }
}

var baseLayers = {
    "MapLayer": mapLayer
};

var overlays = {
    "<span class='checkboxes' style='color:#d38568'>Czech</span>": czech,
    "<span class='checkboxes' style='color:#b0b292'>English (Irish)</span>": english,
    "<span class='checkboxes' style='color:#9b4c4b'>French</span>": french,
    "<span class='checkboxes' style='color:#dac282'>German</span>": german,
    "<span class='checkboxes' style='color:#7d8271'>Italian</span>": italian,
    "<span class='checkboxes' style='color:#a78d5f'>Spanish</span>": spanish,
    "<span class='checkboxes' style='color:#4f84a2'>Swedish</span>": swedish,
    "<span class='checkboxes' style='color:#896b87'>Yiddish</span>": yiddish
};

var map = L.map('map', {
    layers: [mapLayer, czech, english, french, german, italian, spanish, swedish, yiddish]
}).setView([40.719975, -73.990358], 14);

map.setMaxBounds(bounds);
map.on('drag', function() {
    map.panInsideBounds(bounds, {
        animate: false
    });
});

// https://github.com/ismyrnow/leaflet-groupedlayercontrol
var groupedOverlays = {
  "All languages": {
    "<span class='checkboxes' style='color:#d38568'>Czech</span>": czech,
    "<span class='checkboxes' style='color:#b0b292'>English (Irish)</span>": english,
    "<span class='checkboxes' style='color:#9b4c4b'>French</span>": french,
    "<span class='checkboxes' style='color:#dac282'>German</span>": german,
    "<span class='checkboxes' style='color:#7d8271'>Italian</span>": italian,
    "<span class='checkboxes' style='color:#a78d5f'>Spanish</span>": spanish,
    "<span class='checkboxes' style='color:#4f84a2'>Swedish</span>": swedish,
    "<span class='checkboxes' style='color:#896b87'>Yiddish</span>": yiddish
  }
};

var options = {
    groupCheckboxes: true
};


var options = {
    collapsed: false,
    groupCheckboxes: true
};
L.control.groupedLayers(null, groupedOverlays, options).addTo(map);


function popupContent(marker) {
    var content =
        '<div class="popup-thumbnail">' + '<img src=\'' + marker.image + '\' class="thumb" /></div>' +
        '<h2>' + marker.newspaper + '</h2>' +
        '<h3>' + marker.location + ', ' + marker.borough + '</h3>' +
        '<h3 class=\"founding\">Founded in ' + marker.yearFounded + '</h3>' +
        '<h3 class=\"icons\"><i class=\"far fa-comments\"></i>&nbsp; ' + marker.primaryLanguage + 
        '<br /><i class=\"fas fa-user-friends\"></i>&nbsp; ' + marker.community +
        '<br /><i class="far fa-newspaper"></i>&nbsp; '
        + '<a href=\'' + marker.profileURL + '\' target="_blank">View profile</a></h3>';
    return content;
}

function onEachFeature(feature, layer) {
    if (feature.properties && feature.properties.popupContent) {
        layer.bindPopup(feature.properties.popupContent);
    }
}

// https://github.com/cmulders/Leaflet.ThumbnailMap
var layerCopy = L.tileLayer('https://api.mapbox.com/styles/v1/jenche/cjtgq262z04de1fn56eed4apn/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoiamVuY2hlIiwiYSI6ImNqdjczdjJibDBjNGs0NG50ajZybWJiMzQifQ.KLfTJJ0-vPgLSh90Ks9T1w', {minZoom: 10, maxZoom: 10});

L.control.thumbnailmap(layerCopy, {
    position: 'bottomright',
    aimingRectOptions: {color: '#4682B4', weight: 1},
    width: 122,
    height: 210,
    thumbnailBounds: L.latLngBounds([[40.691, -73.9775],[40.914177, -73.912]])
}).addTo(map);

// https://github.com/stefanocudini/leaflet-search
var controlSearch = new L.Control.Search({
                position:'topleft',
                layer: allNewspapers,
                initial: false,
                zoom: 12,
                marker: false,
                textPlaceholder: 'Newspaper',
                textErr: 'Newspaper not found',
                collapsed: false,
                firstTipSubmit: true,
                initial: false,
                moveToLocation: function(latlng, title, map) {
                        map.setView(latlng);
                }
        });
        controlSearch.on('search:locationfound', function(e) {

            if(e.layer._popup)
                e.layer.openPopup();

            }).on('search:collapsed', function(e) {

                featuresLayer.eachLayer(function(layer) {
                    featuresLayer.resetStyle(layer);
                });
        });
        map.addControl( controlSearch );